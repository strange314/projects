# Merch Site + Telegram Order Bot

Проект: сайт-визитка мерча (Django) + Telegram-бот (aiogram) для оформления заказов через бота.

Структура:
- merch_project/ — Django проект с приложением store и orders (API для товаров и заказов)
- bot/ — aiogram-бот, который получает список товаров из API и отправляет заказ в API

Запуск:
1. Создать виртуальное окружение и установить зависимости:
   python -m venv venv
   source venv/bin/activate  # или venv\Scripts\activate на Windows
   pip install -r requirements.txt
2. Выполнить миграции и создать суперпользователя:
   python manage.py migrate
   python manage.py createsuperuser
3. Запустить Django:
   python manage.py runserver
4. Настроить токен бота в bot/config.py и запустить бота:
   cd bot
   python bot.py
