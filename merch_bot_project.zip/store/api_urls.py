from django.urls import path
from . import api_views
urlpatterns = [
    path('', api_views.ProductListAPIView.as_view(), name='api_products'),
    path('<int:pk>/', api_views.ProductDetailAPIView.as_view(), name='api_product_detail'),
]
