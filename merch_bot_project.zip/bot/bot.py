import asyncio, requests, logging
from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from bot.config import TG_BOT_TOKEN, API_BASE_URL

logging.basicConfig(level=logging.INFO)

bot = Bot(TG_BOT_TOKEN)
dp = Dispatcher()

# простое хранение состояния в памяти (user_id -> data)
user_state = {}

@dp.message(Command(commands=['start']))
async def cmd_start(message: types.Message):
    text = 'Привет! Это бот магазина мерча. Выберите действие:\n1) /products — список товаров\n2) /order — оформить заказ'
    await message.answer(text)

@dp.message(Command(commands=['products']))
async def cmd_products(message: types.Message):
    try:
        r = requests.get(f"{API_BASE_URL}/products/", timeout=5)
        data = r.json()
    except Exception as e:
        await message.answer(f'Ошибка при получении товаров: {e}')
        return
    if not data:
        await message.answer('Товары не найдены.')
        return
    for item in data:
        kb = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text='Заказать', callback_data=f"order:{item['id']}")]])
        text = f"{item['name']} — {item['price']} €\n{item['description'][:120]}"
        await message.answer(text, reply_markup=kb)

@dp.callback_query()
async def callbacks(cb: types.CallbackQuery):
    data = cb.data or ''
    if data.startswith('order:'):
        prod_id = int(data.split(':',1)[1])
        # сохраним выбранный товар и запросим количество
        user_state[cb.from_user.id] = {'product_id': prod_id, 'step': 'quantity'}
        await cb.message.answer('Введите количество (например: 1)')
        await cb.answer()

@dp.message()
async def text_handler(message: types.Message):
    uid = message.from_user.id
    if uid in user_state:
        state = user_state[uid]
        step = state.get('step')
        if step == 'quantity':
            try:
                q = int(message.text.strip())
                if q <= 0:
                    raise ValueError()
                state['quantity'] = q
                state['step'] = 'name'
                await message.answer('Введите ваше имя')
            except Exception:
                await message.answer('Неверное количество. Введите целое число, например: 1')
            return
        if step == 'name':
            state['client_name'] = message.text.strip()
            state['step'] = 'phone'
            await message.answer('Введите номер телефона для связи (пример: +358401234567)')
            return
        if step == 'phone':
            state['phone'] = message.text.strip()
            state['step'] = 'address'
            await message.answer('Введите адрес доставки')
            return
        if step == 'address':
            state['address'] = message.text.strip()
            # всё собрано — отправляем заказ на сервер
            try:
                # получим данные товара
                r = requests.get(f"{API_BASE_URL}/products/{state['product_id']}/", timeout=5)
                prod = r.json()
                total = float(prod.get('price',0)) * int(state.get('quantity',1))
                payload = {
                    'product': state['product_id'],
                    'quantity': state['quantity'],
                    'client_name': state['client_name'],
                    'phone': state['phone'],
                    'address': state['address'],
                    'total_price': total,
                }
                r2 = requests.post(f"{API_BASE_URL}/orders/orders/", json=payload, timeout=5)
                if r2.status_code in (200,201):
                    await message.answer(f"Заказ принят!\nТовар: {prod.get('name')}\nКол-во: {state['quantity']}\nИтого: {total} €\nМы свяжемся по номеру: {state['phone']}")
                else:
                    await message.answer(f'Ошибка при отправке заказа: {r2.status_code} {r2.text}')
            except Exception as e:
                await message.answer(f'Ошибка при оформлении заказа: {e}')
            # очистим состояние
            user_state.pop(uid, None)
            return
    # fallback
    await message.answer('Не понял. Используй /products чтобы посмотреть товары или /start.')

if __name__ == '__main__':
    try:
        print('Запуск бота...')
        asyncio.run(dp.start_polling(bot))
    finally:
        asyncio.run(bot.session.close())
