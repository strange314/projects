import asyncio
import json
import os
from datetime import datetime
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from datetime import datetime, timedelta
import requests
import urllib3
import logging
from aiogram.types import Message, LabeledPrice, PreCheckoutQuery, SuccessfulPayment
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, CallbackQuery

from aiogram import Bot, Dispatcher, F, Router, types
from aiogram.filters import CommandStart
from aiogram.utils.keyboard import InlineKeyboardBuilder

# 🔒 Отключаем предупреждение о самоподписанном сертификате
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ---------------- Настройки ----------------
BOT_TOKEN = "7670916317:AAGgoi3Hvfqcdf3_QCbQ2fQF7sHDW2yZUdI"
PAY_TOKEN = "STARS"
API_URL = "https://46.8.64.107:53219/LjBDnWHXsFd_bEzWi_aNTQ"
KEYS_FILE = "vpn_keys.json"
LOG_FILE = "vpn_log.txt"

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()
router = Router()
dp.include_router(router)

logging.basicConfig(
    filename="error_log.txt",
    level=logging.ERROR,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

# Функция для записи ошибок в лог
def log_error(error_message: str):
    logging.error(error_message)

# ---------------- Утилиты ----------------

def load_keys():
    if os.path.exists(KEYS_FILE):
        with open(KEYS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}

def save_keys(data):
    with open(KEYS_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

def log_action(user: types.User, action: str):
    log_entry = (
        f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] "
        f"ID: {user.id} | "
        f"Name: {user.full_name} | "
        f"Username: @{user.username if user.username else '—'} | "
        f"Action: {action}\n"
    )
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(log_entry)

# ---------- Работа с ключами ----------

user_keys = load_keys()

def get_user_data(user_id: int):
    return user_keys.get(str(user_id), {})

def set_unlimited(user_id: int):
    user_id = str(user_id)
    if user_id not in user_keys:
        user_keys[user_id] = {}
    user_keys[user_id]["status"] = "UNLIMITED"
    user_keys[user_id]["issued_at"] = datetime.now().isoformat()
    save_keys(user_keys)

def set_subscription(user_id: int, key: str, days: int):
    user_id = str(user_id)
    now = datetime.now()
    expires_at = now + timedelta(days=days)
    user_keys[user_id] = {
        "status": "ACTIVE",
        "key": key,
        "issued_at": now.isoformat(),
        "expires_at": expires_at.isoformat()
    }
    save_keys(user_keys)

def get_user_status(user_id: int):
    data = get_user_data(user_id)
    return data.get("status", "NONE")



user_payments = {}

# ---------------- Клавиатуры ----------------

reply_keyboard = types.ReplyKeyboardMarkup(
    keyboard=[
        [types.KeyboardButton(text="🔗 Подключиться к VPN")],
        [types.KeyboardButton(text="🔌 Отключиться от VPN")],
        [types.KeyboardButton(text="💫 Купить доступ за ⭐️")]
    ],
    resize_keyboard=True
)

def payment_keyboard():
    builder = InlineKeyboardBuilder()
    builder.button(text="Оплатить 60 ⭐️", pay=True)
    return builder.as_markup()


# ---------------- Админ-панель ----------------

ADMIN_IDS = [1032073308, 367335211]


def is_admin(user_id):
    return user_id in ADMIN_IDS


from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup


class AdminStates(StatesGroup):
    waiting_for_user_id = State()
    waiting_for_unlim_revoke_id = State()
    waiting_for_manual_delete_id = State()


@router.message(F.text == "/admin")
async def admin_panel(message: types.Message):
    if not is_admin(message.from_user.id):
        return await message.answer("⛔ У тебя нет доступа.")

    builder = InlineKeyboardBuilder()
    builder.button(text="👤 Выдать безлимит", callback_data="give_unlimited")
    builder.button(text="📄 Посмотреть логи", callback_data="view_logs")
    builder.button(text="👀 У кого безлимит", callback_data="view_unlimited")
    builder.button(text="❌ Забрать безлимит", callback_data="revoke_unlimited")
    builder.button(text="🚫 Забрать все безлимиты", callback_data="revoke_all_unlimited")
    builder.button(text="🧨 Удалить ключ вручную", callback_data="manual_delete")
    await message.answer("🔧 Админ-панель:", reply_markup=builder.as_markup())


@router.callback_query(F.data == "give_unlimited")
async def ask_for_id(callback: types.CallbackQuery, state: FSMContext):
    await callback.message.answer("✉️ Введи Telegram ID пользователя, которому выдать безлимит:")
    await state.set_state(AdminStates.waiting_for_user_id)


@router.message(AdminStates.waiting_for_user_id)
async def give_unlimited(message: types.Message, state: FSMContext):
    user_id = message.text.strip()
    user_keys[user_id] = "UNLIMITED"
    save_keys(user_keys)
    await message.answer(f"✅ Пользователю с ID {user_id} выдан безлимит.")
    await state.clear()


@router.callback_query(F.data == "view_logs")
async def view_logs(callback: types.CallbackQuery):
    if os.path.exists(LOG_FILE):
        with open(LOG_FILE, "r", encoding="utf-8") as f:
            logs = f.read()[-4000:]
        await callback.message.answer(f"📄 Последние логи:\n\n<code>{logs}</code>", parse_mode="HTML")
    else:
        await callback.message.answer("❌ Лог-файл не найден.")


@router.callback_query(F.data == "view_unlimited")
async def view_unlimited(callback: types.CallbackQuery):
    unlimited_users = [uid for uid, kid in user_keys.items() if kid == "UNLIMITED"]
    if unlimited_users:
        formatted = "\n".join(unlimited_users)
        await callback.message.answer(f"👥 Пользователи с безлимитом:\n<code>{formatted}</code>", parse_mode="HTML")
    else:
        await callback.message.answer("🤷 Никто не имеет безлимита.")


@router.callback_query(F.data == "revoke_unlimited")
async def revoke_prompt(callback: types.CallbackQuery, state: FSMContext):
    await callback.message.answer("✉️ Введи Telegram ID пользователя, у которого забрать безлимит:")
    await state.set_state(AdminStates.waiting_for_unlim_revoke_id)


@router.message(AdminStates.waiting_for_unlim_revoke_id)
async def revoke_unlimited(message: types.Message, state: FSMContext):
    user_id = message.text.strip()
    if user_keys.get(user_id) == "UNLIMITED":
        user_keys.pop(user_id)
        save_keys(user_keys)
        await message.answer(f"❌ Безлимит у пользователя {user_id} удалён.")
    else:
        await message.answer("⚠️ У этого пользователя нет безлимита.")
    await state.clear()


@router.callback_query(F.data == "revoke_all_unlimited")
async def revoke_all_unlimited(callback: types.CallbackQuery):
    count = 0
    to_delete = [uid for uid, kid in user_keys.items() if kid == "UNLIMITED"]
    for uid in to_delete:
        user_keys.pop(uid)
        count += 1
    save_keys(user_keys)
    await callback.message.answer(f"🚫 Удалено {count} безлимит(ов).")


@router.callback_query(F.data == "manual_delete")
async def manual_delete_prompt(callback: types.CallbackQuery, state: FSMContext):
    await callback.message.answer("🧨 Введи Telegram ID пользователя, чей VPN-ключ нужно удалить вручную:")
    await state.set_state(AdminStates.waiting_for_manual_delete_id)


@router.message(AdminStates.waiting_for_manual_delete_id)
async def manual_delete(message: types.Message, state: FSMContext):
    user_id = message.text.strip()
    if user_id in user_keys:
        user_keys.pop(user_id)
        save_keys(user_keys)
        await message.answer(f"🗑️ Ключ пользователя {user_id} удалён из локального хранилища.")
    else:
        await message.answer("⚠️ Ключ не найден.")
    await state.clear()


# ---------------- Команды ----------------

@router.message(CommandStart())
async def start_cmd(message: types.Message):
    log_action(message.from_user, "Нажал /start")
    await message.answer(
        "👋 <b>Привет!</b> Добро пожаловать в нашего <b>Telegram VPN-бота</b>!\n\n"
        "🔐 <b>Надёжный доступ</b> к свободному интернету за считанные секунды.\n\n"
        "📡 <b>Как мы работаем:</b> \n\n"
        "Для работы нашего VPN, вам необходимо установить клиент Outline:\n"
        "🤖 <a href='https://outline-vpn.com'>Скачать для Android</a>\n"
        "🍎 <a href='https://outline-vpn.com'>Скачать для iOS</a>\n\n"
        "💫 <b>Возможности:</b>\n"
        "🔗 Быстрое подключение к VPN\n"
        "💳 Покупка подписки через Telegram Stars\n"
        "🛡️ Работает через API Outline\n"
        "🧑‍💻 Поддержка и удобное управление\n\n"
        "👇 Выбери нужный пункт в меню и пользуйся свободным интернетом без ограничений!",
        parse_mode="HTML",
        reply_markup=reply_keyboard
    )


@router.message(F.text == "🔗 Подключиться к VPN")
async def connect_vpn(message: types.Message):
    user_id = str(message.from_user.id)

    # Проверяем, есть ли у пользователя подписка или безлимитный доступ
    user_data = user_keys.get(user_id)
    if user_data == "UNLIMITED":
        # Если у пользователя безлимитный доступ
        response = requests.post(f"{API_URL}/access-keys", verify=False)
        if response.status_code == 201:
            data = response.json()
            access_url = data["accessUrl"]
            log_action(message.from_user, "подключился к VPN (безлимитный доступ)")
            await message.answer(
                "✅ У тебя безлимитный доступ.\n"
                f"🔗 Нажми для копирования:\n<code>{access_url}</code>",
                parse_mode="HTML"
            )
    elif user_data:
        subscription_end = datetime.strptime(user_data["subscription_end"], '%Y-%m-%d %H:%M:%S')

        # Проверяем, не истёк ли срок подписки
        if subscription_end < datetime.now():
            await message.answer("⚠️ Ваша подписка истекла. Пожалуйста, оплатите снова.")
            return
        else:
            # Подключение к VPN, если подписка ещё активна
            response = requests.post(f"{API_URL}/access-keys", verify=False)
            if response.status_code == 201:
                data = response.json()
                access_url = data["accessUrl"]
                log_action(message.from_user, "подключился к VPN (с подпиской)")
                await message.answer(
                    f"✅ Твоя подписка активна до {subscription_end.strftime('%Y-%m-%d')}.\n"
                    f"🔗 Нажми для копирования:\n<code>{access_url}</code>",
                    parse_mode="HTML"
                )
    else:
        await message.answer("⚠️ У тебя нет активной подписки. Пожалуйста, купи доступ.")

@router.message(F.text == "🔌 Отключиться от VPN")
async def disconnect_vpn(message: types.Message):
    user_id = str(message.from_user.id)

    # Проверяем, есть ли у пользователя безлимитный доступ
    if user_keys.get(user_id) == "UNLIMITED":
        await message.answer("✅ У тебя безлимитный доступ к VPN. Ты не можешь отключить его.")
        return

    # Если у пользователя нет активного ключа
    key_id = user_keys.get(user_id)
    if not key_id:
        await message.answer("⚠️ У тебя нет активного VPN-доступа.")
        return

    try:
        # Попробуем отправить запрос на удаление ключа
        response = requests.delete(f"{API_URL}/access-keys/{key_id}", verify=False)

        if response.status_code == 204:
            # Если ключ был успешно удалён, удаляем его из локального файла
            user_keys.pop(user_id)
            save_keys(user_keys)
            log_action(message.from_user, "отключился от VPN")

            await message.answer("🔌 VPN отключён.")
        elif response.status_code == 404:
            # Если сервер сообщает, что ключ не найден (уже удалён), удаляем его из локального файла
            user_keys.pop(user_id, None)
            save_keys(user_keys)
            log_action(message.from_user, f"Ключ {key_id} не найден на сервере, удалён из локальных данных")

            await message.answer(f"🔌 Ключ {key_id} уже удалён на сервере, локальные данные очищены.")
        else:
            # Обработка других ошибок
            await message.answer(f"❌ Ошибка при отключении VPN: {response.status_code}. Попробуйте позже.")
            log_action(message.from_user, f"Ошибка при отключении: {response.status_code}")

    except requests.exceptions.RequestException as e:
        # Ловим проблемы с сетью
        await message.answer(f"❌ Ошибка сети при отключении от VPN:\n{str(e)}")
        log_action(message.from_user, f"Ошибка сети при отключении: {str(e)}")

    except Exception as e:
        # Ловим другие ошибки
        await message.answer(f"❌ Произошла непредвиденная ошибка:\n{str(e)}")
        log_action(message.from_user, f"Непредвиденная ошибка при отключении: {str(e)}")

class GiftState(StatesGroup):
    waiting_for_username = State()

@router.message(F.text == "💫 Купить доступ за ⭐️")
async def show_tariffs(message: Message):
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🛡 30 дней — 60⭐", callback_data="buy_30d")],
        [InlineKeyboardButton(text="🛡 3 месяца — 170⭐", callback_data="buy_3m")],
        [InlineKeyboardButton(text="🛡 6 месяцев — 320⭐", callback_data="buy_6m")],
        [InlineKeyboardButton(text="🛡 12 месяцев — 525⭐", callback_data="buy_12m")],
        [InlineKeyboardButton(text="🎁 Подарить 30 дней — 60⭐", callback_data="gift_30d")],
        [InlineKeyboardButton(text="🎁 Подарить 3 месяца — 170⭐", callback_data="gift_3m")],
        [InlineKeyboardButton(text="🎁 Подарить 6 месяцев — 320⭐", callback_data="gift_6m")],
        [InlineKeyboardButton(text="🎁 Подарить 12 месяцев — 525⭐", callback_data="gift_12m")],
    ])
    await message.answer("Выберите вариант подписки:", reply_markup=kb)

# Цены
SUBSCRIPTIONS = {
    "buy_30d": {"label": "VPN на 30 дней", "amount": 60},
    "buy_3m": {"label": "VPN на 3 месяца", "amount": 170},
    "buy_6m": {"label": "VPN на 6 месяцев", "amount": 320},
    "buy_12m": {"label": "VPN на 12 месяцев", "amount": 525},
    "gift_30d": {"label": "🎁 VPN в подарок на 30 дней", "amount": 60},
    "gift_3m": {"label": "🎁 VPN в подарок на 3 месяца", "amount": 170},
    "gift_6m": {"label": "🎁 VPN в подарок на 6 месяцев", "amount": 320},
    "gift_12m": {"label": "🎁 VPN в подарок на 12 месяцев", "amount": 525},
}

@router.callback_query(F.data.in_(SUBSCRIPTIONS.keys()))
async def send_invoice(call: CallbackQuery, bot: Bot):
    sub = SUBSCRIPTIONS[call.data]
    await bot.send_invoice(
        chat_id=call.from_user.id,
        title="Подписка на VPN",
        description=sub["label"],
        provider_token=PAY_TOKEN,
        currency="XTR",
        prices=[LabeledPrice(label=sub["label"], amount=sub["amount"])],
        payload=call.data
    )
    await call.answer()

@router.pre_checkout_query()
async def pre_checkout_query(pre_checkout_q: PreCheckoutQuery, bot: Bot):
    await bot.answer_pre_checkout_query(pre_checkout_q.id, ok=True)

# Расчёт окончания подписки
def calculate_subscription_end(subscription_type: str):
    today = datetime.now()
    if "30d" in subscription_type:
        return today + timedelta(days=30)
    elif "3m" in subscription_type:
        return today + timedelta(days=90)
    elif "6m" in subscription_type:
        return today + timedelta(days=180)
    elif "12m" in subscription_type:
        return today + timedelta(days=365)
    return today

# Успешная оплата
@router.message(F.successful_payment)
async def successful_payment(message: Message, state: FSMContext):
    payload = message.successful_payment.invoice_payload
    sub = SUBSCRIPTIONS.get(payload)

    if not sub:
        await message.answer("❌ Что-то пошло не так. Обратитесь в поддержку.")
        return

    if payload.startswith("gift_"):
        # Запускаем состояние ожидания username
        await state.set_state(GiftState.waiting_for_username)
        await state.update_data(subscription_type=payload)
        await message.answer("🎁 Оплата прошла успешно! Теперь введите @username пользователя, которому хотите подарить подписку:")
    else:
        user_id = str(message.from_user.id)
        subscription_end = calculate_subscription_end(payload)
        user_keys[user_id] = {
            "subscription_start": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            "subscription_end": subscription_end.strftime('%Y-%m-%d %H:%M:%S'),
            "subscription_type": payload
        }
        save_keys(user_keys)
        await message.answer(
            f"✅ Оплата прошла успешно! Вы получили {sub['label']}.\n"
            f"Подписка активна с {user_keys[user_id]['subscription_start']} по {user_keys[user_id]['subscription_end']}.\n"
            f"Спасибо за покупку!"
        )

# Обработка ввода username
@router.message(GiftState.waiting_for_username)
async def handle_gift_username(message: Message, state: FSMContext):
    data = await state.get_data()
    payload = data["subscription_type"]
    recipient_username = message.text.strip().lstrip("@")

    # 🔹 Блок 1: Получаем user_id по username
    try:
        user = await bot.get_chat(recipient_username)
        recipient_id = str(user.id)
    except Exception as e:
        await message.answer(f"❌ Не удалось найти пользователя @{recipient_username}. Проверьте, что username правильный и пользователь запускал бота.")
        return

    # 🔹 Блок 2: Сохраняем доступ по user_id, а не по username
    subscription_end = calculate_subscription_end(payload)
    user_keys[recipient_id] = {
        "subscription_start": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        "subscription_end": subscription_end.strftime('%Y-%m-%d %H:%M:%S'),
        "subscription_type": payload
    }
    save_keys(user_keys)

    # 🔹 Блок 3: Отправляем сообщение получателю
    try:
        await bot.send_message(
            chat_id=recipient_id,
            text=(
                f"🎁 Тебе подарили {SUBSCRIPTIONS[payload]['label']}!\n"
                f"Подписка активна до {subscription_end.strftime('%Y-%m-%d %H:%M:%S')}.\n"
                "🔐 Нажми «Подключиться к VPN» в меню."
            )
        )
    except Exception as e:
        await message.answer("⚠️ Не удалось отправить уведомление пользователю. Возможно, он не запускал бота.")

    # Ответ дарителю
    await message.answer(
        f"🎉 Вы подарили {SUBSCRIPTIONS[payload]['label']} пользователю @{recipient_username}!\n"
        f"Доступ активен до {subscription_end.strftime('%Y-%m-%d %H:%M:%S')}."
    )

    await state.clear()
# ---------------- Запуск ----------------

async def main():
    print("Бот запущен...")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())