import asyncio
from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
import requests
from bot.config import TG_BOT_TOKEN, API_BASE_URL

bot = Bot(TG_BOT_TOKEN)
dp = Dispatcher()

start_kb = ReplyKeyboardMarkup(keyboard=[[KeyboardButton(text='Сделать заказ')]], resize_keyboard=True)

@dp.message(Command(commands=['start']))
async def cmd_start(message: types.Message):
    await message.answer('Привет! Я помогу оформить заказ из ресторана. Выбери "Сделать заказ".', reply_markup=start_kb)

@dp.message()
async def text_handler(message: types.Message):
    if 'сделать заказ' in message.text.lower():
        await message.answer('Отправь данные в формате: Имя; Адрес; Список блюд; Цена; Номер телефона')
    elif ';' in message.text:
        parts = [p.strip() for p in message.text.split(';')]
        if len(parts) < 5:
            await message.answer('Неверный формат. Нужно 5 полей, разделённых точкой с запятой.')
            return
        payload = {
            'client_name': parts[0],
            'address': parts[1],
            'items': parts[2],
            'price': parts[3],
            'phone': parts[4],
        }
        try:
            r = requests.post(f"{API_BASE_URL}/orders/", json=payload, timeout=5)
            if r.status_code in (200,201):
                await message.answer(f"Заказ подтверждён!\nИмя: {parts[0]}\nАдрес: {parts[1]}\nБлюда: {parts[2]}\nЦена: {parts[3]}\nТелефон: {parts[4]}")
            else:
                await message.answer(f'Ошибка сервера: {r.status_code} {r.text}')
        except Exception as e:
            await message.answer(f'Ошибка при отправке: {e}')
    else:
        await message.answer('Не понял команду. Нажми "Сделать заказ".')

if __name__ == '__main__':
    import logging
    logging.basicConfig(level=logging.INFO)
    print('Запуск бота...')
    try:
        asyncio.run(dp.start_polling(bot))
    finally:
        asyncio.run(bot.session.close())
