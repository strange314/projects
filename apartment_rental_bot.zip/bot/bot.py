import asyncio
from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
import requests
from datetime import datetime
from bot.config import TG_BOT_TOKEN, API_BASE_URL

bot = Bot(TG_BOT_TOKEN)
dp = Dispatcher()

start_kb = ReplyKeyboardMarkup(keyboard=[
    [KeyboardButton(text='Список квартир'), KeyboardButton(text='Добавить объявление')],
], resize_keyboard=True)

@dp.message(Command(commands=['start']))
async def cmd_start(message: types.Message):
    await message.answer('Привет! Я помогаю арендовать квартиры. Выбери действие:', reply_markup=start_kb)

@dp.message()
async def text_handler(message: types.Message):
    text = message.text.lower()
    if 'список квартир' in text or 'apartments' in text:
        await send_apartments_list(message)
    elif 'добавить' in text or 'add' in text:
        await message.answer('Чтобы добавить объявление, отправь сообщение в формате:\n\n'
                             'Название; Город; Район; Цена; Контакт; Описание\n\n'
                             'Пример:\nСтудия у парка; Хельсинки; Центр; 50; +358401234567; Хорошая студия')
    elif ';' in message.text:
        # попытка добавить объявление
        parts = [p.strip() for p in message.text.split(';')]
        if len(parts) < 6:
            await message.answer('Неверный формат. Нужно 6 полей, разделённых точкой с запятой.')
            return
        payload = {
            'title': parts[0],
            'city': parts[1],
            'district': parts[2],
            'price_per_day': parts[3],
            'contact': parts[4],
            'description': parts[5],
        }
        try:
            r = requests.post(f"{API_BASE_URL}/apartments/", json=payload, timeout=5)
            if r.status_code in (200,201):
                await message.answer('Объявление отправлено! Оно появится после проверки в админке.')
            else:
                await message.answer(f'Ошибка сервера: {r.status_code} {r.text}')
        except Exception as e:
            await message.answer(f'Ошибка при отправке: {e}')
    else:
        await message.answer('Не понял команду. Напиши "Список квартир" или "Добавить объявление".')

async def send_apartments_list(message):
    try:
        r = requests.get(f"{API_BASE_URL}/apartments/", timeout=5)
        data = r.json()
    except Exception as e:
        await message.answer(f'Не удалось получить список: {e}')
        return
    if not data:
        await message.answer('Пока нет доступных квартир.')
        return
    for item in data:
        text = f"{item.get('title')} — {item.get('city')}, {item.get('district')}\nЦена/день: {item.get('price_per_day')}\n{item.get('description')}\nКонтакт: {item.get('contact')}"
        kb = types.InlineKeyboardMarkup()
        kb.add(types.InlineKeyboardButton(text='Забронировать', callback_data=f"book:{item.get('id')}" ))
        await message.answer(text, reply_markup=kb)

@dp.callback_query()
async def callbacks(cb: types.CallbackQuery):
    data = cb.data
    if data and data.startswith('book:'):
        apt_id = data.split(':',1)[1]
        await cb.message.answer('Напиши даты в формате YYYY-MM-DD YYYY-MM-DD (начало конец)')
        await cb.answer()
        # store in memory (simple)
        await dp.storage.set_bucket(cb.from_user.id, {'booking_apt': apt_id})

@dp.message()
async def date_handler(message: types.Message):
    # very naive date parse
    parts = message.text.strip().split()
    if len(parts) == 2:
        try:
            start = datetime.fromisoformat(parts[0]).date()
            end = datetime.fromisoformat(parts[1]).date()
        except Exception:
            await message.answer('Неверный формат дат. Используй YYYY-MM-DD YYYY-MM-DD')
            return
        # retrieve apt id (best-effort)
        try:
            bucket = await dp.storage.get_bucket(message.from_user.id)
            apt_id = bucket.get('booking_apt')
        except Exception:
            apt_id = None
        if not apt_id:
            await message.answer('Не найден выбранный объект. Нажмите "Список квартир" и выберите снова.')
            return
        payload = {
            'apartment': int(apt_id),
            'start_date': str(start),
            'end_date': str(end),
            # 'user': None  -- anonymous booking
        }
        try:
            r = requests.post(f"{API_BASE_URL}/bookings/", json=payload, timeout=5)
            if r.status_code in (200,201):
                await message.answer('Заявка на бронирование отправлена владельцу. Ожидайте подтверждения.')
            else:
                await message.answer(f'Ошибка при бронировании: {r.status_code} {r.text}')
        except Exception as e:
            await message.answer(f'Ошибка: {e}')
    else:
        # fallthrough to other handlers
        return

if __name__ == '__main__':
    import logging
    logging.basicConfig(level=logging.INFO)
    print('Запуск бота...')
    try:
        asyncio.run(dp.start_polling(bot))
    finally:
        asyncio.run(bot.session.close())
