from rest_framework import serializers
from .models import Apartment, ApartmentPhoto, Booking

class ApartmentPhotoSerializer(serializers.ModelSerializer):
    class Meta:
        model = ApartmentPhoto
        fields = ['id', 'image']

class ApartmentSerializer(serializers.ModelSerializer):
    photos = ApartmentPhotoSerializer(source='photos', many=True, read_only=True)
    class Meta:
        model = Apartment
        fields = ['id','title','city','district','description','price_per_day','contact','photos']

class BookingSerializer(serializers.ModelSerializer):
    class Meta:
        model = Booking
        fields = ['id','apartment','user','start_date','end_date','approved']
