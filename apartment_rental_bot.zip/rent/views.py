from rest_framework import generics
from .models import Apartment, Booking, ApartmentPhoto
from .serializers import ApartmentSerializer, BookingSerializer
from rest_framework.permissions import AllowAny
from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser
from django.http import JsonResponse

class ApartmentListCreateAPIView(generics.ListCreateAPIView):
    queryset = Apartment.objects.all().order_by('-created_at')
    serializer_class = ApartmentSerializer
    permission_classes = [AllowAny]

class BookingCreateAPIView(generics.CreateAPIView):
    queryset = Booking.objects.all()
    serializer_class = BookingSerializer
    permission_classes = [AllowAny]
