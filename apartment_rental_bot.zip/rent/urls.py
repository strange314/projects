from django.urls import path
from . import views

urlpatterns = [
    path('apartments/', views.ApartmentListCreateAPIView.as_view(), name='apartments'),
    path('bookings/', views.BookingCreateAPIView.as_view(), name='bookings'),
]
