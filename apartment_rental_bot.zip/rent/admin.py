from django.contrib import admin
from .models import Apartment, ApartmentPhoto, Booking

class ApartmentPhotoInline(admin.TabularInline):
    model = ApartmentPhoto
    extra = 1

@admin.register(Apartment)
class ApartmentAdmin(admin.ModelAdmin):
    list_display = ('title', 'city', 'district', 'price_per_day', 'owner')
    inlines = [ApartmentPhotoInline]

@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ('apartment', 'user', 'start_date', 'end_date', 'approved')
