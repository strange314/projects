from django.db import models
from django.contrib.auth import get_user_model

User = get_user_model()

class Apartment(models.Model):
    title = models.CharField(max_length=200)
    city = models.CharField(max_length=100)
    district = models.CharField(max_length=100, blank=True)
    description = models.TextField(blank=True)
    price_per_day = models.DecimalField(max_digits=10, decimal_places=2)
    owner = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    contact = models.CharField(max_length=200, blank=True)  # телефон или username
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.title} — {self.city} ({self.price_per_day})"

class ApartmentPhoto(models.Model):
    apartment = models.ForeignKey(Apartment, related_name='photos', on_delete=models.CASCADE)
    image = models.CharField(max_length=500, blank=True)  # placeholder: путь или URL

class Booking(models.Model):
    apartment = models.ForeignKey(Apartment, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    start_date = models.DateField()
    end_date = models.DateField()
    created_at = models.DateTimeField(auto_now_add=True)
    approved = models.BooleanField(default=False)

    def __str__(self):
        return f"Бронь {self.apartment} {self.start_date} — {self.end_date}"
