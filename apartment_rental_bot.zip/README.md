# Telegram Rental Bot (Django + aiogram)

Проект-скелет: **Telegram-бот для аренды квартир** и Django backend с SQLite.

## Что внутри
- Django backend (`rentproject/` + `rent/` app)
  - Модели: `Apartment`, `Booking`
  - Админ-панель для управления квартирами и пользователями
  - Простые JSON API endpoints:
    - `GET /api/apartments/` — список квартир
    - `POST /api/apartments/` — добавить объявление (арендодатель)
    - `POST /api/bookings/` — создать бронь
- aiogram-бот (`bot/bot.py`)
  - Команды: `/start`, `/apartments`, `/add`, `/book`
  - Интерфейс на русском языке
  - Общается с Django backend через HTTP API

## Требования
- Python 3.10+
- Зависимости в `requirements.txt`

## Быстрый запуск (локально)
1. Клонируй/распакуй проект.
2. Создай виртуальное окружение и установи зависимости:
   ```bash
   python -m venv venv
   source venv/bin/activate  # или venv\Scripts\activate на Windows
   pip install -r requirements.txt
   ```
3. Выполни миграции и создай суперпользователя:
   ```bash
   cd rentproject
   python manage.py migrate
   python manage.py createsuperuser
   ```
4. Запусти Django:
   ```bash
   python manage.py runserver
   ```
5. Настрой переменные в `bot/config.py` (TOKEN бота и URL сервера), затем запусти бота:
   ```bash
   cd bot
   python bot.py
   ```

## Примечание
Это минимальный шаблон проекта для портфолио — содержит рабочую структуру и основной код-флоу. 
Добавь свои доработки (валидацию форм, загрузку фото в MEDIA, авторизацию по токенам, тесты и т.д.) для полноты.

