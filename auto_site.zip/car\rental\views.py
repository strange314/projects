from django.shortcuts import get_object_or_404, redirect
from .forms import BookingForm
from .models import Car
from .models import Booking
from django.shortcuts import render

def car_list(request):
    cars = Car.objects.all()  # Все автомобили
    car_bookings = []
    for car in cars:
        bookings = Booking.objects.filter(car=car, is_approved=True)  # Только подтвержденные брони
        car_bookings.append({'car': car, 'bookings': bookings})

    return render(request, 'rental/car_list.html', {
        'car_bookings': car_bookings,  # Передаем список автомобилей с их бронированиями
    })


def car_calendar(request, car_id):
    car = get_object_or_404(Car, id=car_id)
    bookings = Booking.objects.filter(car=car, is_approved=True).order_by('start_date')

    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid():
            booking = form.save(commit=False)
            booking.car = car
            booking.save()
            return redirect('car_list')
    else:
        form = BookingForm()

    return render(request, 'rental/car_calendar.html', {
        'car': car,
        'bookings': bookings,
        'form': form
    })
