from django.contrib import admin
from .models import Car, Booking

@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ('car', 'full_name', 'start_date', 'end_date', 'is_approved')
    list_filter = ('is_approved', 'car')
    search_fields = ('full_name', 'car__name')
    actions = ['approve_booking']

    def approve_booking(self, request, queryset):
        queryset.update(is_approved=True)
        for booking in queryset:
            booking.car.available = False
            booking.car.save()
        self.message_user(request, "Выбранные бронирования подтверждены.")

    approve_booking.short_description = "Подтвердить выбранные бронирования"

# Регистрация модели Car в админке
@admin.register(Car)
class CarAdmin(admin.ModelAdmin):
    list_display = ('name', 'price_per_day', 'available')
    list_filter = ('available',)
    search_fields = ('name',)
