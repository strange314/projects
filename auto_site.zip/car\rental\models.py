from django.db import models
from django.core.validators import RegexValidator

class Car(models.Model):
    name = models.CharField(max_length=100, verbose_name="Название автомобиля")
    price_per_day = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Цена за день")
    available = models.BooleanField(default=True, verbose_name="Доступен для аренды")

    def __str__(self):
        return f"{self.name} - {self.price_per_day} руб/день"


class Booking(models.Model):
    car = models.ForeignKey(Car, on_delete=models.CASCADE, related_name='bookings')
    start_date = models.DateField()
    end_date = models.DateField()
    full_name = models.CharField(max_length=255, default='Как к вам обращаться')
    phone_number = models.CharField(
        max_length=15,
        validators=[
            RegexValidator(
                regex=r'^\+?\d{10,15}$',
                message="Введите корректный номер телефона (10-15 цифр, может начинаться с +)."
            )
        ],
        verbose_name="Номер телефона"
    )
    is_approved = models.BooleanField(default=False)

    def __str__(self):
        return f"Бронь: {self.car.name} ({self.start_date} - {self.end_date})"





