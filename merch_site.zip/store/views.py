from django.shortcuts import render, get_object_or_404
from .models import Product

def index(request):
    products = Product.objects.all().order_by('-created_at')[:20]
    return render(request, 'store/index.html', {'products': products, 'contacts': None})

def product_detail(request, slug):
    product = get_object_or_404(Product, slug=slug)
    return render(request, 'store/detail.html', {'product': product, 'contacts': None})

def gallery(request):
    products = Product.objects.all().order_by('-created_at')
    return render(request, 'store/gallery.html', {'products': products})
