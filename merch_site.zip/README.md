# Merch Site (Django)

Минималистичный сайт-визитка для продажи мерча.
Функции:
- Главная страница с приветствием и брендом
- Каталог товаров (футболки, худи, кепки) с фото, описанием и ценой
- Галерея товаров
- Контакты: Telegram, Instagram, телефон, email
- Django admin для управления товарами
- SQLite для хранения данных

Запуск:
1. python -m venv venv
2. source venv/bin/activate  # на Windows venv\Scripts\activate
3. pip install -r requirements.txt
4. python manage.py migrate
5. python manage.py createsuperuser
6. python manage.py runserver
